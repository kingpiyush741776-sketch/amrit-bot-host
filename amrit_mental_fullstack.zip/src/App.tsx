import React, { useState, useEffect, useRef } from 'react';
import {
  Server,
  Play,
  Square,
  RotateCw,
  Terminal,
  Check,
  Copy,
  Plus,
  Trash2,
  Shield,
  Bot,
  Zap,
  Cloud,
  Download,
  ExternalLink,
  Cpu,
  Layers,
  Activity,
  Info,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
  Search,
  Key,
  FileCode,
  Radio,
  Clock,
  Sparkles,
  Database,
  HeartPulse,
  Eye,
  X,
  Smartphone,
  Share2,
  Globe
} from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

interface TokenValidationResult {
  validating: boolean;
  valid?: boolean;
  error?: string;
  botInfo?: {
    id: number;
    first_name: string;
    username: string;
    can_join_groups?: boolean;
    can_read_all_group_messages?: boolean;
  };
}

interface HostedInstance {
  id: string;
  name: string;
  ownerId: string;
  status: 'STOPPED' | 'STARTING' | 'RUNNING' | 'ERROR';
  pid?: number;
  autoRestart?: boolean;
  restartCount?: number;
  startedAt?: number;
  uptimeSeconds: number;
  primaryBotUsername?: string;
  primaryBotFirstName?: string;
  fleetCount: number;
  fleetUsernames: string[];
  brandName: string;
  logCount: number;
  recentLogs: string[];
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'host' | 'cloud' | 'remote' | 'vault' | 'instances' | 'forever'>('host');

  // Form State
  const [instanceName, setInstanceName] = useState('Amrit-Fleet-Alpha');
  const [primaryToken, setPrimaryToken] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [apiId, setApiId] = useState('2040');
  const [apiHash, setApiHash] = useState('b18441a1ff607e10a989891a5462e627');
  const [showAdvancedApi, setShowAdvancedApi] = useState(false);
  const [brandName, setBrandName] = useState('AMRIT X MENTAL');
  const [sudoUsers, setSudoUsers] = useState('');
  const [autoRestart, setAutoRestart] = useState(true);

  // Fleet Tokens (Bots 2 to 10)
  const [fleetTokens, setFleetTokens] = useState<string[]>([]);

  // Validation States
  const [primaryValidation, setPrimaryValidation] = useState<TokenValidationResult>({ validating: false });
  const [fleetValidations, setFleetValidations] = useState<{ [index: number]: TokenValidationResult }>({});

  // Active Running Instance State
  const [currentInstanceId, setCurrentInstanceId] = useState<string | null>(null);
  const [instanceStatus, setInstanceStatus] = useState<'STOPPED' | 'STARTING' | 'RUNNING' | 'ERROR'>('STOPPED');
  const [instancePid, setInstancePid] = useState<number | null>(null);
  const [uptimeSeconds, setUptimeSeconds] = useState(0);
  const [logs, setLogs] = useState<string[]>([
    '⚡ AMRIT X MENTAL 24/7 Web Hosting Engine Active',
    '💾 Persistent Database (database.json): Connected & Ready',
    '🛡️ 24/7 Watchdog: Auto-restart on crash enabled',
    '👉 Enter Bot Token & Owner ID, then click "LAUNCH 24/7 BOT ONLINE" to start hosting!',
  ]);

  // System Health
  const [serverHealth, setServerHealth] = useState<any>(null);
  const [allInstances, setAllInstances] = useState<HostedInstance[]>([]);
  const [loadingAction, setLoadingAction] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Command Vault Search
  const [vaultSearch, setVaultSearch] = useState('');
  const [vaultCategory, setVaultCategory] = useState<string>('all');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  // Script Code Viewer Modal
  const [scriptModalOpen, setScriptModalOpen] = useState(false);
  const [rawScriptCode, setRawScriptCode] = useState('');
  const [loadingScript, setLoadingScript] = useState(false);

  // Live Ping Test State
  const [pingResult, setPingResult] = useState<{ latencyMs: number; status: string; memoryMB?: number } | null>(null);
  const [testingPing, setTestingPing] = useState(false);

  // PWA Install & Public Share States
  const { isInstallable, isInstalled, isIOS, install: installPWA } = usePWAInstall();
  const [publicShareModalOpen, setPublicShareModalOpen] = useState(false);
  const [showIOSInstallGuide, setShowIOSInstallGuide] = useState(false);
  const [easySetupModalOpen, setEasySetupModalOpen] = useState(false);

  // Terminal Ref
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  // Auto-scroll terminal
  useEffect(() => {
    if (autoScroll && terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, autoScroll]);

  // Fetch initial system health & instances list
  useEffect(() => {
    fetchHealth();
    fetchInstances();
    const interval = setInterval(() => {
      fetchHealth();
      fetchInstances();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Poll logs and status if an instance is active
  useEffect(() => {
    if (!currentInstanceId) return;

    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch(`/api/instances/${currentInstanceId}/logs`);
        if (res.ok) {
          const data = await res.json();
          if (data.ok) {
            setInstanceStatus(data.status);
            if (data.pid) setInstancePid(data.pid);
            if (data.uptimeSeconds !== undefined) setUptimeSeconds(data.uptimeSeconds);
            if (Array.isArray(data.logs) && data.logs.length > 0) {
              setLogs(data.logs);
            }
          }
        }
      } catch (e) {}
    }, 2000);

    return () => clearInterval(pollInterval);
  }, [currentInstanceId]);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchHealth = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        setServerHealth(data);
      }
    } catch (e) {}
  };

  const fetchInstances = async () => {
    try {
      const res = await fetch('/api/instances');
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.instances)) {
          setAllInstances(data.instances);
        }
      }
    } catch (e) {}
  };

  // Validate Primary Token
  const handleValidatePrimary = async () => {
    if (!primaryToken.trim()) {
      showToast('Please enter a Bot Token first.', 'error');
      return;
    }
    setPrimaryValidation({ validating: true });
    try {
      const res = await fetch('/api/bot/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: primaryToken.trim() }),
      });
      const data = await res.json();
      if (data.ok && data.result) {
        setPrimaryValidation({
          validating: false,
          valid: true,
          botInfo: data.result,
        });
        showToast(`✅ Verified: @${data.result.username} (${data.result.first_name})`, 'success');
      } else {
        setPrimaryValidation({
          validating: false,
          valid: false,
          error: data.error || 'Invalid token.',
        });
        showToast(`❌ Error: ${data.error || 'Token rejected by Telegram'}`, 'error');
      }
    } catch (e: any) {
      setPrimaryValidation({ validating: false, valid: false, error: e.message });
      showToast(`Connection failed: ${e.message}`, 'error');
    }
  };

  // Validate Fleet Token
  const handleValidateFleetToken = async (index: number) => {
    const token = fleetTokens[index]?.trim();
    if (!token) return;
    setFleetValidations(prev => ({ ...prev, [index]: { validating: true } }));
    try {
      const res = await fetch('/api/bot/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      });
      const data = await res.json();
      if (data.ok && data.result) {
        setFleetValidations(prev => ({
          ...prev,
          [index]: { validating: false, valid: true, botInfo: data.result },
        }));
      } else {
        setFleetValidations(prev => ({
          ...prev,
          [index]: { validating: false, valid: false, error: data.error },
        }));
      }
    } catch (e: any) {
      setFleetValidations(prev => ({
        ...prev,
        [index]: { validating: false, valid: false, error: e.message },
      }));
    }
  };

  const handleAddFleetSlot = () => {
    if (fleetTokens.length >= 9) {
      showToast('Maximum 10 bots supported in one fleet (1 Primary + 9 Fleet).', 'error');
      return;
    }
    setFleetTokens(prev => [...prev, '']);
  };

  const handleRemoveFleetSlot = (index: number) => {
    setFleetTokens(prev => prev.filter((_, i) => i !== index));
    setFleetValidations(prev => {
      const next = { ...prev };
      delete next[index];
      return next;
    });
  };

  // Deploy / Start Bot
  const handleDeployBot = async () => {
    if (!primaryToken.trim()) {
      showToast('Primary Bot Token is required.', 'error');
      return;
    }
    if (!ownerId.trim()) {
      showToast('Owner Telegram User ID is required.', 'error');
      return;
    }

    setLoadingAction(true);
    setInstanceStatus('STARTING');
    showToast('🚀 Deploying 24/7 Bot Worker...', 'info');

    try {
      const res = await fetch('/api/instances/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instanceId: currentInstanceId || undefined,
          name: instanceName.trim() || 'Amrit-Mental-Fleet',
          primaryToken: primaryToken.trim(),
          fleetTokens: fleetTokens.filter(t => t.trim().length > 0),
          ownerId: ownerId.trim(),
          apiId: apiId.trim() || '2040',
          apiHash: apiHash.trim() || 'b18441a1ff607e10a989891a5462e627',
          sudoUsers: sudoUsers ? sudoUsers.split(',').map(s => s.trim()) : [],
          brandName: brandName.trim() || 'AMRIT X MENTAL',
          autoRestart,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setCurrentInstanceId(data.instanceId);
        setInstanceStatus('RUNNING');
        showToast(`🎉 Bot @${data.primaryBot?.username || 'Fleet'} is now hosted 24/7!`, 'success');
        fetchInstances();
      } else {
        setInstanceStatus('ERROR');
        showToast(`Deployment failed: ${data.error}`, 'error');
      }
    } catch (e: any) {
      setInstanceStatus('ERROR');
      showToast(`Network error: ${e.message}`, 'error');
    } finally {
      setLoadingAction(false);
    }
  };

  // Stop Bot
  const handleStopBot = async () => {
    if (!currentInstanceId) return;
    setLoadingAction(true);
    try {
      const res = await fetch(`/api/instances/${currentInstanceId}/stop`, { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setInstanceStatus('STOPPED');
        showToast('🛑 Bot stopped. Auto-restart disabled.', 'info');
        fetchInstances();
      } else {
        showToast(data.error || 'Failed to stop bot.', 'error');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'error');
    } finally {
      setLoadingAction(false);
    }
  };

  // Restart Bot
  const handleRestartBot = async () => {
    if (!currentInstanceId) return;
    setLoadingAction(true);
    showToast('🔄 Restarting bot with 24/7 Watchdog...', 'info');
    try {
      const res = await fetch(`/api/instances/${currentInstanceId}/restart`, { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setInstanceStatus('RUNNING');
        showToast('✅ Bot restarted successfully!', 'success');
        fetchInstances();
      } else {
        showToast(data.error || 'Failed to restart.', 'error');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'error');
    } finally {
      setLoadingAction(false);
    }
  };

  // Delete Instance
  const handleDeleteInstance = async (id: string) => {
    if (!confirm('Are you sure you want to delete this hosted bot instance?')) return;
    try {
      const res = await fetch(`/api/instances/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.ok) {
        if (currentInstanceId === id) {
          setCurrentInstanceId(null);
          setInstanceStatus('STOPPED');
        }
        showToast('Instance deleted from 24/7 database.', 'info');
        fetchInstances();
      }
    } catch (e: any) {
      showToast(e.message, 'error');
    }
  };

  // Download Configured Script
  const handleDownloadCustomScript = async () => {
    try {
      const res = await fetch('/api/export-pack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          primaryToken: primaryToken.trim(),
          fleetTokens: fleetTokens.filter(t => t.trim().length > 0),
          ownerId: ownerId.trim(),
          apiId: apiId.trim(),
          apiHash: apiHash.trim(),
          sudoUsers: sudoUsers ? sudoUsers.split(',').map(s => s.trim()) : [],
          brandName: brandName.trim(),
        }),
      });
      const data = await res.json();
      if (data.ok && data.files) {
        const pyCode = data.files['amrit_mental_upgraded.py'];
        const blob = new Blob([pyCode], { type: 'text/x-python;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'amrit_mental_configured.py';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        showToast('📥 Pre-configured script downloaded!', 'success');
      }
    } catch (e: any) {
      showToast(`Export error: ${e.message}`, 'error');
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
    showToast(`Copied: ${text}`, 'success');
  };

  const handleOpenScriptViewer = async () => {
    setScriptModalOpen(true);
    if (!rawScriptCode) {
      setLoadingScript(true);
      try {
        const res = await fetch('/api/raw-script');
        const text = await res.text();
        setRawScriptCode(text);
      } catch (e: any) {
        showToast('Failed to load script: ' + e.message, 'error');
      } finally {
        setLoadingScript(false);
      }
    }
  };

  const handleCopyFullScript = async () => {
    try {
      let code = rawScriptCode;
      if (!code) {
        showToast('Fetching script...', 'info');
        const res = await fetch('/api/raw-script');
        code = await res.text();
        setRawScriptCode(code);
      }
      await navigator.clipboard.writeText(code);
      showToast('📋 Full script copied to clipboard (4,140 lines)!', 'success');
    } catch (e: any) {
      showToast('Copy failed: ' + e.message, 'error');
    }
  };

  const handleDirectBlobDownload = async () => {
    try {
      showToast('Preparing script download...', 'info');
      let code = rawScriptCode;
      if (!code) {
        const res = await fetch('/api/raw-script');
        code = await res.text();
        setRawScriptCode(code);
      }
      const blob = new Blob([code], { type: 'application/x-python;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'amrit_mental_upgraded.py';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      showToast('✅ amrit_mental_upgraded.py download started!', 'success');
    } catch (e: any) {
      showToast('Download error: ' + e.message, 'error');
    }
  };

  const handleTestPing = async () => {
    try {
      setTestingPing(true);
      const start = performance.now();
      const res = await fetch('/api/ping-test');
      const data = await res.json();
      const end = performance.now();
      const latency = Math.round(end - start);
      setPingResult({ latencyMs: latency, status: data.status, memoryMB: data.memoryUsageMB });
      showToast(`⚡ Heartbeat OK: ${latency}ms latency`, 'success');
    } catch (err: any) {
      showToast('Ping failed: ' + err.message, 'error');
    } finally {
      setTestingPing(false);
    }
  };

  const handleDownloadDbBackup = () => {
    const a = document.createElement('a');
    a.href = '/api/database/backup';
    a.download = 'amrit_mental_database_backup.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('💾 Database backup downloaded!', 'success');
  };

  const [userDomainInput, setUserDomainInput] = useState('');

  const handleDownloadFullProjectZip = async () => {
    try {
      showToast('📦 Packaging real ZIP file...', 'info');
      const res = await fetch('/api/download/full-project-zip');
      if (!res.ok) throw new Error('Download failed: ' + res.statusText);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'amrit_mental_fullstack.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 3000);
      showToast('✅ amrit_mental_fullstack.zip (Real ZIP) downloaded!', 'success');
    } catch (e: any) {
      showToast('Download error: ' + e.message, 'error');
    }
  };

  const formatUptime = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const keepAliveUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/keepalive` : '/api/keepalive';

  const commandList = [
    { cmd: '+allgcnc <text>', desc: 'Jitne bhi groups me bots hain, sabhi me ek sath parallel NC chalata hai (5 bots, 1 bot ya 10 bots)', cat: 'nc' },
    { cmd: '/stopglobalnc', desc: 'Sabhi groups me chal rahe global NC ko ek jhatke me stop karta hai', cat: 'nc' },
    { cmd: '/gcpfp [delay]', desc: 'Kisi photo par reply karo: sabhi groups me profile photo automatic rotate karne lagta hai', cat: 'pfp' },
    { cmd: '/stopgcpfp', desc: 'Sabhi groups me chal rahe profile picture rotation ko stop karta hai', cat: 'pfp' },
    { cmd: '/gcpfpset', desc: 'Kisi photo par reply karo: ek click me sabhi groups ki profile picture instant change ho jati hai', cat: 'pfp' },
    { cmd: '/tempmail', desc: 'Telegram ke andar disposable fake email generate karta hai + OTP incoming inbox check button', cat: 'dhasu' },
    { cmd: '+rollcall', desc: 'Military fleet inspection: Saare 10 bots ki real-time online status aur ping ms latency check karta hai', cat: 'dhasu' },
    { cmd: '/bodyguard [on|off]', desc: 'VIP Amrit shield: agar koi non-admin Owner ke message par badtameezi karega to bots counter-dialogue marenge', cat: 'dhasu' },
    { cmd: '+iq @user', desc: 'Target user ka 3-stage animated brainwave scan karke funny IQ Scorecard nikalta hai', cat: 'troll' },
    { cmd: '+roast @user', desc: 'Target user ke liye savage VIP Amrit x Mental signature roast dialogue generate karta hai', cat: 'troll' },
    { cmd: '/stealthlock [on|off]', desc: 'Bina kisi alert ke group ke media, stickers, GIFs aur voice notes ko silently lock kar deta hai', cat: 'admin' },
    { cmd: '+rnc <text>', desc: 'Random high-speed Name Cycling mode with fancy fonts & glitch frames', cat: 'nc' },
    { cmd: '+flamenc <text>', desc: 'Flame fire animated Name Cycling mode', cat: 'nc' },
    { cmd: '+lunanc <text>', desc: 'Luna moon phase themed name cycle', cat: 'nc' },
    { cmd: '+purenc <text>', desc: 'Pure clean Unicode font styling name loop', cat: 'nc' },
    { cmd: '+mentalnc <text>', desc: 'Official Amrit X Mental personal NC mode', cat: 'nc' },
    { cmd: '+amritnc <text>', desc: 'Ghost Amrit stealth mode', cat: 'nc' },
    { cmd: '+amritxnc <text>', desc: 'Amrit Light speed hyperfire mode', cat: 'nc' },
    { cmd: '/fakeban @user', desc: 'Target par realistic fake animated ban screen chalta hai', cat: 'troll' },
    { cmd: '/fakekick @user', desc: 'Fake kick animation message generate karta hai', cat: 'troll' },
    { cmd: '+matrix @user', desc: 'Hacker Matrix code rain animation screen', cat: 'troll' },
    { cmd: '+loading', desc: 'Animated progress loading bar in Telegram chat', cat: 'troll' },
    { cmd: '+spinner', desc: 'High-speed spinner with brand labels', cat: 'troll' },
    { cmd: '/joingc <link>', desc: 'Saare bots ek sath invite link se group join karte hain aur auto-admin banne ki request bhejte hain', cat: 'admin' },
    { cmd: '/mygc', desc: 'Bots ke radar me jitne groups active hain unki list aur invite link deta hai', cat: 'admin' },
    { cmd: '/allpromote', desc: 'Group me sabhi fleet bots ko automatic admin promote karta hai', cat: 'admin' },
    { cmd: '/ping', desc: 'Real-time Telegram server latency and bot uptime check karta hai', cat: 'admin' },
    { cmd: '/stop', desc: 'Current group me chal rahe kisi bhi NC ya troll loop ko stop karta hai', cat: 'admin' },
  ];

  const filteredCommands = commandList.filter(c => {
    const matchesCat = vaultCategory === 'all' || c.cat === vaultCategory;
    const matchesSearch = c.cmd.toLowerCase().includes(vaultSearch.toLowerCase()) || c.desc.toLowerCase().includes(vaultSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-lg shadow-2xl border backdrop-blur-md flex items-center gap-3 transition-all transform translate-y-0 text-sm ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
              : toastMessage.type === 'error'
              ? 'bg-rose-950/90 border-rose-500/50 text-rose-200'
              : 'bg-cyan-950/90 border-cyan-500/50 text-cyan-200'
          }`}
        >
          {toastMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
          {toastMessage.type === 'error' && <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />}
          {toastMessage.type === 'info' && <Info className="w-5 h-5 text-cyan-400 shrink-0" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Top Banner / Brand Header */}
      <header className="border-b border-cyan-900/40 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-700 flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
              <Zap className="w-6 h-6 text-black fill-current animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-black tracking-wider bg-gradient-to-r from-cyan-400 via-blue-300 to-indigo-300 bg-clip-text text-transparent">
                  AMRIT X MENTAL
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest bg-cyan-500/10 text-cyan-300 rounded border border-cyan-500/30">
                  24/7 CLOUD HOSTING
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Self-Hosted 24/7 Platform • Auto-Restart Watchdog • Multi-User Database
              </p>
            </div>
          </div>

          {/* Engine Status Badges & App Actions */}
          <div className="flex items-center gap-2.5 text-xs flex-wrap">
            <button
              type="button"
              onClick={() => {
                if (isInstallable) {
                  installPWA();
                } else if (isIOS) {
                  setShowIOSInstallGuide(true);
                } else {
                  setPublicShareModalOpen(true);
                }
              }}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-md shadow-emerald-500/20 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
            >
              <Smartphone className="w-4 h-4" />
              <span>{isInstalled ? '✅ App Installed' : '📲 Install App'}</span>
            </button>

            <button
              type="button"
              onClick={() => setEasySetupModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>⚡ Setup Kaise Karein?</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('forever')}
              className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-purple-400" />
              <span>🌐 Custom Domain (24/7)</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadFullProjectZip}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              title="Download entire web app source as ZIP for Render/Koyeb/Custom Domain"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Web (.ZIP)</span>
            </button>

            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-300 font-medium">DB: Online</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60">
              <HeartPulse className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span className="text-slate-300 font-medium">24/7 Watchdog</span>
            </div>
          </div>
        </div>
      </header>

      {/* 24/7 Public Cloud Notification Banner */}
      <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 border-b border-cyan-900/40 py-2 px-4 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-cyan-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>
              <strong>🌐 Official Public Web App Active:</strong> Anyone can access and host their Telegram bot fleet 24/7 without login restrictions!
            </span>
          </div>
          <button
            type="button"
            onClick={() => setPublicShareModalOpen(true)}
            className="text-cyan-400 hover:text-cyan-300 underline font-semibold cursor-pointer"
          >
            Get Public URL & Install App Guide →
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav className="border-b border-slate-800 bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 flex overflow-x-auto no-scrollbar gap-1 py-1">
          <button
            onClick={() => setActiveTab('host')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'host'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>🚀 1-Click Online Web Host</span>
          </button>

          <button
            onClick={() => setActiveTab('instances')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'instances'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>👥 Multi-User Fleet Monitor ({allInstances.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('cloud')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'cloud'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Cloud className="w-4 h-4" />
            <span>📦 Cloud Export (Render / Koyeb / Termux)</span>
          </button>

          <button
            onClick={() => setActiveTab('remote')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'remote'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>🎮 Web Remote Deck</span>
          </button>

          <button
            onClick={() => setActiveTab('vault')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'vault'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>📜 Command Vault (50+ Commands)</span>
          </button>

          <button
            onClick={() => setActiveTab('forever')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'forever'
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>🌐 24/7 Forever Hosting Hub</span>
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 py-6 flex-1 w-full">
        {/* TAB 1: 1-CLICK ONLINE WEB HOST */}
        {activeTab === 'host' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Configuration Form (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              {/* Card 1: Bot Credentials */}
              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2.5">
                    <Key className="w-5 h-5 text-cyan-400" />
                    <h2 className="text-base font-bold text-slate-100">Primary Bot & Owner Setup</h2>
                  </div>
                  <span className="text-[11px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    24/7 Hosting Enabled
                  </span>
                </div>

                {/* Primary Bot Token */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                    <span>Primary Bot Token</span>
                    <span className="text-[11px] text-slate-400 font-normal">From @BotFather on Telegram</span>
                  </label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={primaryToken}
                        onChange={(e) => {
                          setPrimaryToken(e.target.value);
                          setPrimaryValidation({ validating: false });
                        }}
                        placeholder="e.g. 7123456789:AAHk99_xyz..."
                        className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-cyan-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleValidatePrimary}
                      disabled={primaryValidation.validating || !primaryToken.trim()}
                      className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 hover:border-cyan-500/50 transition-all flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {primaryValidation.validating ? (
                        <RotateCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                      ) : (
                        <Check className="w-3.5 h-3.5" />
                      )}
                      <span>Verify</span>
                    </button>
                  </div>

                  {/* Validation status badge */}
                  {primaryValidation.valid && primaryValidation.botInfo && (
                    <div className="mt-2 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>
                          <strong>@{primaryValidation.botInfo.username}</strong> ({primaryValidation.botInfo.first_name}) — ID: {primaryValidation.botInfo.id}
                        </span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-[10px] font-bold">ONLINE READY</span>
                    </div>
                  )}
                  {primaryValidation.valid === false && (
                    <div className="mt-2 p-2 rounded-lg bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{primaryValidation.error || 'Invalid token. Please check and re-enter.'}</span>
                    </div>
                  )}
                </div>

                {/* Owner Telegram User ID */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                    <span>Owner Telegram User ID</span>
                    <span className="text-[11px] text-slate-400 font-normal">Get from Telegram @userinfobot</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={ownerId}
                      onChange={(e) => setOwnerId(e.target.value)}
                      placeholder="e.g. 6148293412"
                      className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-cyan-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Aapka numeric ID jisse bot aapko Primary Owner maane aur sabhi VIP / Admin commands chalane de.
                  </p>
                </div>

                {/* 24/7 Auto-Restart Toggle */}
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <HeartPulse className="w-3.5 h-3.5 text-emerald-400" />
                      <span>24/7 Watchdog Auto-Restart & Persistence</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Crash ya server reboot hone par bot ko automatically bina manual intervention ke restart karega.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={autoRestart}
                    onChange={(e) => setAutoRestart(e.target.checked)}
                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                  />
                </div>

                {/* Instance Label & Brand Name */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Host Instance Name</label>
                    <input
                      type="text"
                      value={instanceName}
                      onChange={(e) => setInstanceName(e.target.value)}
                      placeholder="Amrit-Mental-Fleet"
                      className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Brand Tag</label>
                    <input
                      type="text"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      placeholder="AMRIT X MENTAL"
                      className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                {/* Advanced API Credentials */}
                <div className="pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setShowAdvancedApi(!showAdvancedApi)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 font-medium transition-colors"
                  >
                    <span>{showAdvancedApi ? '▼ Hide' : '▶ Show'} Advanced Telegram API Credentials (Optional)</span>
                  </button>

                  {showAdvancedApi && (
                    <div className="mt-3 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
                      <p className="text-[11px] text-slate-400">
                        Default standard Telegram App credentials already configured.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[11px] text-slate-300 font-semibold">API ID</label>
                          <input
                            type="text"
                            value={apiId}
                            onChange={(e) => setApiId(e.target.value)}
                            className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-slate-300 font-semibold">API HASH</label>
                          <input
                            type="text"
                            value={apiHash}
                            onChange={(e) => setApiHash(e.target.value)}
                            className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[11px] text-slate-300 font-semibold">Additional Sudo User IDs (Comma-separated)</label>
                        <input
                          type="text"
                          value={sudoUsers}
                          onChange={(e) => setSudoUsers(e.target.value)}
                          placeholder="e.g. 543210987, 987654321"
                          className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Card 2: Multi-Bot Fleet Slots (Bot 2 to Bot 10) */}
              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2.5">
                    <Bot className="w-5 h-5 text-indigo-400" />
                    <div>
                      <h2 className="text-base font-bold text-slate-100">Multi-Bot Fleet Setup (Up to 10 Bots)</h2>
                      <p className="text-[11px] text-slate-400">
                        Add secondary bot tokens for high-speed multi-bot relay, raid defense, and name cycling.
                      </p>
                    </div>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-300 font-bold border border-indigo-500/30">
                    {fleetTokens.length + 1} / 10 Bots Active
                  </span>
                </div>

                {fleetTokens.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-950/40 border border-dashed border-slate-800 text-center space-y-2">
                    <p className="text-xs text-slate-400">
                      Currently using <strong>1 Primary Bot</strong> mode.
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Multi-bot mode enables rotation between 2 to 10 bots for high-speed NC cycles, Global GC PFP, and Military Roll-Calls!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {fleetTokens.map((token, idx) => {
                      const valState = fleetValidations[idx];
                      return (
                        <div key={idx} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-indigo-300">Bot #{idx + 2} Token</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveFleetSlot(idx)}
                              className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                              title="Remove Bot"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={token}
                              onChange={(e) => {
                                const newTokens = [...fleetTokens];
                                newTokens[idx] = e.target.value;
                                setFleetTokens(newTokens);
                              }}
                              placeholder={`Token for Bot #${idx + 2}...`}
                              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                            />
                            <button
                              type="button"
                              onClick={() => handleValidateFleetToken(idx)}
                              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700"
                            >
                              Verify
                            </button>
                          </div>

                          {valState?.valid && valState.botInfo && (
                            <div className="text-[11px] text-emerald-400 flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Verified: @{valState.botInfo.username} ({valState.botInfo.first_name})</span>
                            </div>
                          )}
                          {valState?.valid === false && (
                            <div className="text-[11px] text-rose-400 flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>{valState.error || 'Token rejected'}</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {fleetTokens.length < 9 && (
                  <button
                    type="button"
                    onClick={handleAddFleetSlot}
                    className="w-full py-2.5 rounded-xl border border-dashed border-indigo-500/40 hover:border-indigo-400 bg-indigo-500/5 hover:bg-indigo-500/10 text-indigo-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Add Fleet Bot Slot (#{fleetTokens.length + 2})</span>
                  </button>
                )}
              </div>

              {/* Master Control Buttons */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleDeployBot}
                  disabled={loadingAction || !primaryToken.trim() || !ownerId.trim()}
                  className="flex-1 py-3 px-6 rounded-xl font-black text-sm tracking-wide bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-black shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  {loadingAction ? (
                    <RotateCw className="w-4 h-4 animate-spin text-black" />
                  ) : (
                    <Play className="w-4 h-4 fill-black" />
                  )}
                  <span>{instanceStatus === 'RUNNING' ? 'REDEPLOY & UPDATE 24/7 BOT' : '🚀 LAUNCH 24/7 BOT ONLINE'}</span>
                </button>

                {instanceStatus === 'RUNNING' && (
                  <>
                    <button
                      type="button"
                      onClick={handleRestartBot}
                      disabled={loadingAction}
                      className="px-4 py-3 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Restart process"
                    >
                      <RotateCw className="w-4 h-4" />
                      <span>Restart</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleStopBot}
                      disabled={loadingAction}
                      className="px-4 py-3 rounded-xl font-bold text-xs bg-rose-950/60 hover:bg-rose-900/80 text-rose-200 border border-rose-500/50 flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Stop bot"
                    >
                      <Square className="w-4 h-4 fill-current" />
                      <span>Stop</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Right Column: Live Terminal Console & System Status (5 cols) */}
            <div className="lg:col-span-5 space-y-4 flex flex-col">
              {/* Status Header Box */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Host State</span>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`w-3 h-3 rounded-full ${
                        instanceStatus === 'RUNNING'
                          ? 'bg-emerald-400 shadow-lg shadow-emerald-500/50 animate-pulse'
                          : instanceStatus === 'STARTING'
                          ? 'bg-amber-400 animate-ping'
                          : instanceStatus === 'ERROR'
                          ? 'bg-rose-500'
                          : 'bg-slate-600'
                      }`}
                    ></span>
                    <span className="text-sm font-black tracking-wider text-slate-100">
                      {instanceStatus === 'RUNNING'
                        ? '🟢 24/7 ONLINE'
                        : instanceStatus === 'STARTING'
                        ? '🟡 STARTING UP...'
                        : instanceStatus === 'ERROR'
                        ? '🔴 PROCESS ERROR'
                        : '⚪ OFFLINE'}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Session Uptime</span>
                  <div className="text-sm font-mono font-bold text-cyan-300 mt-1">
                    {instanceStatus === 'RUNNING' ? formatUptime(uptimeSeconds) : '00:00:00'}
                  </div>
                </div>
              </div>

              {/* Real-Time Live Terminal */}
              <div className="rounded-2xl bg-black/90 border border-cyan-900/40 shadow-2xl flex-1 flex flex-col min-h-[480px] overflow-hidden">
                <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                    <span className="ml-2 text-xs font-mono font-bold text-slate-400 flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                      terminal@amrit-mental-host:~#
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setAutoScroll(!autoScroll)}
                      className={`text-[10px] px-2 py-0.5 rounded font-mono transition-colors ${
                        autoScroll ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {autoScroll ? 'Scroll: ON' : 'Scroll: OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(logs.join('\n'), 'all_logs')}
                      className="text-slate-400 hover:text-cyan-300 p-1"
                      title="Copy all logs"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setLogs([])}
                      className="text-slate-400 hover:text-rose-400 p-1"
                      title="Clear terminal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 p-4 overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1 select-text">
                  {logs.length === 0 ? (
                    <div className="text-slate-600 italic">No output yet. Click "LAUNCH 24/7 BOT ONLINE" to start streaming.</div>
                  ) : (
                    logs.map((line, i) => {
                      const isErr = line.includes('⚠️') || line.includes('Error') || line.includes('Traceback');
                      const isOk = line.includes('🟢') || line.includes('success') || line.includes('Verified') || line.includes('ONLINE');
                      const isLaunch = line.includes('🚀') || line.includes('Launching') || line.includes('Initializing');
                      return (
                        <div
                          key={i}
                          className={`break-words ${
                            isErr
                              ? 'text-rose-400'
                              : isOk
                              ? 'text-emerald-300'
                              : isLaunch
                              ? 'text-cyan-300 font-bold'
                              : 'text-slate-300'
                          }`}
                        >
                          {line}
                        </div>
                      );
                    })
                  )}
                  <div ref={terminalEndRef} />
                </div>

                <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-900 text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Process PID: {instancePid || 'None'}</span>
                  <span>Database: Persistent JSON</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MULTI-USER FLEET MONITOR */}
        {activeTab === 'instances' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-100">Multi-User Hosted Bot Fleet ({allInstances.length})</h2>
                <p className="text-xs text-slate-400">
                  Multiple users can host their bots on this website simultaneously. All instances are stored in persistent database.
                </p>
              </div>
              <button
                type="button"
                onClick={fetchInstances}
                className="px-3 py-1.5 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Refresh Instances</span>
              </button>
            </div>

            {allInstances.length === 0 ? (
              <div className="p-12 rounded-2xl bg-slate-900/40 border border-dashed border-slate-800 text-center space-y-3">
                <Bot className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-sm font-semibold text-slate-300">No Active Hosted Instances Found</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  When you or other users enter bot tokens in Tab 1 and click "LAUNCH 24/7 BOT ONLINE", they will appear and run here.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {allInstances.map((inst) => (
                  <div key={inst.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                          <span>{inst.name}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              inst.status === 'RUNNING'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {inst.status}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Owner: {inst.ownerId} • Fleet: {inst.fleetCount} Bot(s)
                        </span>
                      </div>
                      <div className="text-right text-xs font-mono text-cyan-300">
                        {inst.uptimeSeconds > 0 ? formatUptime(inst.uptimeSeconds) : 'Stopped'}
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 font-mono text-[11px] text-slate-400 space-y-1">
                      <div>🤖 Primary: @{inst.primaryBotUsername || 'Unknown'} ({inst.primaryBotFirstName || 'Bot'})</div>
                      {inst.fleetUsernames.length > 0 && (
                        <div>👥 Fleet: {inst.fleetUsernames.map(u => `@${u}`).join(', ')}</div>
                      )}
                      <div className="text-[10px] text-indigo-400 flex items-center gap-1 mt-1">
                        <HeartPulse className="w-3 h-3" />
                        <span>24/7 Auto-Restart: {inst.autoRestart ? 'ENABLED' : 'DISABLED'} • Restarts: {inst.restartCount || 0}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setCurrentInstanceId(inst.id);
                          setActiveTab('host');
                          showToast(`Viewing instance "${inst.name}"`, 'info');
                        }}
                        className="flex-1 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 cursor-pointer"
                      >
                        View Logs & Console
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteInstance(inst.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 border border-slate-800 transition-colors cursor-pointer"
                        title="Delete Instance"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: CLOUD EXPORT */}
        {activeTab === 'cloud' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center">
                  <Cloud className="w-6 h-6 text-indigo-400" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-100">Permanent 24/7 Cloud Deployment Package</h2>
                  <p className="text-xs text-slate-400">
                    Deploy on Render, Koyeb, Docker, VPS, or Android Termux in 1 click!
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-3">
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-cyan-400" />
                      <span className="text-sm font-bold text-slate-200">1. Full Python Script (.py)</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Download or copy the 100% full, working script with all fixes, handlers & commands.
                    </p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <a
                      href="/api/download-script"
                      download="amrit_mental_upgraded.py"
                      className="w-full py-2.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
                    >
                      <Download className="w-4 h-4" />
                      <span>Direct Download .py File</span>
                    </a>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={handleCopyFullScript}
                        className="py-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Copy Code</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleOpenScriptViewer}
                        className="py-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-emerald-400" />
                        <span>View Code</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-emerald-400" />
                      <span className="text-sm font-bold text-slate-200">2. Run on Android (Termux)</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Copy 1-line command to install Python and start the bot in Termux background!
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopy(
                        'pkg update -y && pkg install -y python git curl && pip install "python-telegram-bot==21.6" httpx aiohttp && curl -O https://ais-dev-u7v6rsqr2bf7zrx7wn5jwm-244882406374.asia-southeast1.run.app/amrit_mental_upgraded.py && python amrit_mental_upgraded.py',
                        'termux_cmd'
                      )
                    }
                    className="w-full py-2.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{copiedCmd === 'termux_cmd' ? 'Copied Termux Command!' : 'Copy 1-Line Termux Runner'}</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span className="text-sm font-bold text-slate-200">3. Render.com / Koyeb (24/7 Free)</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Free Background Worker on Render.
                    </p>
                  </div>
                  <a
                    href="https://dashboard.render.com"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open Render Dashboard</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: WEB REMOTE DECK */}
        {activeTab === 'remote' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <Radio className="w-6 h-6 text-cyan-400" />
                  <div>
                    <h2 className="text-base font-bold text-slate-100">Web Remote Control Deck</h2>
                    <p className="text-xs text-slate-400">
                      Execute commands directly through this web interface without opening Telegram.
                    </p>
                  </div>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${
                  instanceStatus === 'RUNNING'
                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  Status: {instanceStatus}
                </span>
              </div>

              {instanceStatus !== 'RUNNING' ? (
                <div className="p-6 rounded-xl bg-slate-950/50 border border-dashed border-slate-800 text-center space-y-3">
                  <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
                  <p className="text-sm font-semibold text-slate-200">No Bot Instance Currently Running</p>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Please visit the <strong>"🚀 1-Click Online Web Host"</strong> tab, enter your Primary Bot Token & Owner ID, and click <strong>"LAUNCH 24/7 BOT ONLINE"</strong> first.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('host')}
                    className="px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold cursor-pointer"
                  >
                    Go to Web Host Tab
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-cyan-400">Global All-GC NC</span>
                    <p className="text-[11px] text-slate-400">Triggers NC across all known groups using all present bots.</p>
                    <div className="font-mono text-xs text-slate-300 p-2 rounded bg-slate-900 border border-slate-800">
                      +allgcnc AMRIT X MENTAL
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-rose-400">Stop Global NC</span>
                    <p className="text-[11px] text-slate-400">Immediately stops all active NC loops across every group.</p>
                    <div className="font-mono text-xs text-slate-300 p-2 rounded bg-slate-900 border border-slate-800">
                      /stopglobalnc
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-indigo-400">Global GC PFP Rotator</span>
                    <p className="text-[11px] text-slate-400">Rotates profile photos across all groups where bots are added.</p>
                    <div className="font-mono text-xs text-slate-300 p-2 rounded bg-slate-900 border border-slate-800">
                      /gcpfp 10
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-emerald-400">Military Roll-Call</span>
                    <p className="text-[11px] text-slate-400">Inspects all 10 bots, uptime, latency ping in milliseconds.</p>
                    <div className="font-mono text-xs text-slate-300 p-2 rounded bg-slate-900 border border-slate-800">
                      +rollcall
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: COMMAND VAULT */}
        {activeTab === 'vault' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-slate-100">Command Vault & Cheat Sheet</h2>
                <p className="text-xs text-slate-400">Search and copy all 50+ built-in NC modes, Trolls, Group Controls & Dhasu Features.</p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={vaultSearch}
                  onChange={(e) => setVaultSearch(e.target.value)}
                  placeholder="Search commands..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {[
                { id: 'all', label: 'All Commands' },
                { id: 'nc', label: '🌀 NC Modes (45+)' },
                { id: 'pfp', label: '🖼️ Global GC PFP' },
                { id: 'dhasu', label: '⚡ Dhasu VIP (RollCall, TempMail)' },
                { id: 'troll', label: '😈 Trolls & Animations (+iq, +roast)' },
                { id: 'admin', label: '🛡️ Group Control & Admin' },
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setVaultCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    vaultCategory === cat.id
                      ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredCommands.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 transition-all flex items-start justify-between gap-3 group"
                >
                  <div className="space-y-1">
                    <div className="font-mono text-xs font-bold text-cyan-300 group-hover:text-cyan-200">
                      {item.cmd}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-normal">{item.desc}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(item.cmd, `cmd_${idx}`)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors shrink-0 cursor-pointer"
                    title="Copy command"
                  >
                    {copiedCmd === `cmd_${idx}` ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: 24/7 FOREVER HOSTING HUB */}
        {activeTab === 'forever' && (
          <div className="space-y-6">
            {/* Header Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-indigo-950/70 border border-emerald-500/30 shadow-2xl flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white tracking-wide">24/7 Forever Hosting Hub</h2>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      Salo Tak Uptime Active
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Production architecture with auto-healing watchdog, heartbeat monitors & multi-cloud deployment.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleTestPing}
                  disabled={testingPing}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/30 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Activity className="w-4 h-4" />
                  <span>{testingPing ? 'Pinging Server...' : '⚡ Test Heartbeat Ping'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadDbBackup}
                  className="px-3.5 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Database className="w-4 h-4" />
                  <span>Backup DB</span>
                </button>
              </div>
            </div>

            {/* MASTER CARD: APNA CUSTOM DOMAIN & 24/7 PUBLIC HOSTING (NO 403 ERROR) */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border-2 border-purple-500/40 shadow-2xl space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-purple-900/50">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 shrink-0">
                    <Globe className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black text-white tracking-wide">
                        Apna Custom Domain & 24/7 Permanent Public Host (No 403 Error)
                      </h3>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        Salo Tak 100% Free
                      </span>
                    </div>
                    <p className="text-xs text-purple-200/80 mt-0.5">
                      Kyu 403 error aa raha hai? Aur apne custom domain (jaise <span className="text-cyan-300 font-mono">bot.yourdomain.com</span>) par kaise salo tak chalayein:
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadFullProjectZip}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-purple-500/30 flex items-center gap-2 transition-all cursor-pointer active:scale-95 shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>📥 DOWNLOAD FULL PROJECT (.ZIP)</span>
                </button>
              </div>

              {/* Why 403 Error Happens Info Box */}
              <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/30 flex items-start gap-3 text-xs text-rose-200">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold text-rose-300">403 Forbidden Error Kyu Aata Hai?</span>
                  <p className="text-rose-200/90 leading-relaxed">
                    Google AI Studio ka preview link (<code className="bg-rose-900/50 px-1.5 py-0.5 rounded font-mono">ais-dev-...run.app</code>) Google ka ek private development container hota hai. Google ki security policy ke tahat bina Google developer account ke bahar se aane wale kisi bhi visitor ko Google <strong>403 Forbidden</strong> block kar deta hai.
                    <br />
                    <strong>Permanent Solution:</strong> Is poore web platform ko aap apne custom domain ya Render.com par 3 minute mein host kar sakte hain — wahan <strong>kabhi 403 error nahi aayega</strong>, aur koi bhi banda 24/7 salo tak apna bot host kar sakega!
                  </p>
                </div>
              </div>

              {/* 3-Step Custom Domain Deployment Guide */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/20 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 font-black flex items-center justify-center text-sm">
                    1
                  </div>
                  <span className="font-bold text-white text-sm">Download Project Zip</span>
                  <p className="text-slate-400 leading-relaxed">
                    Upar <strong>"Download Full Project (.ZIP)"</strong> dabayein. Isme Dockerfile, React frontend, Express server aur Telegram bot engine pehle se fully configured hain.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/20 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-300 font-black flex items-center justify-center text-sm">
                    2
                  </div>
                  <span className="font-bold text-white text-sm">GitHub Par Upload Karein</span>
                  <p className="text-slate-400 leading-relaxed">
                    Apne free GitHub account me naya private/public repo banakar is zip ki files drag-and-drop karke commit kar dein.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/20 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 font-black flex items-center justify-center text-sm">
                    3
                  </div>
                  <span className="font-bold text-white text-sm">Render.com Par 1-Click Deploy</span>
                  <p className="text-slate-400 leading-relaxed">
                    <a href="https://render.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline font-semibold">Render.com</a> par jakar <strong>New Web Service</strong> chunein, apna GitHub repo select karein — yeh automatically 24/7 deploy kar dega!
                  </p>
                </div>
              </div>

              {/* Interactive DNS Record Calculator for Custom Domain */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span>Apna Domain DNS Generator (GoDaddy, Namecheap, Cloudflare, Hostinger):</span>
                  </span>
                  <span className="text-[11px] text-slate-400">Type your domain to get exact DNS records</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  <input
                    type="text"
                    value={userDomainInput}
                    onChange={(e) => setUserDomainInput(e.target.value)}
                    placeholder="e.g. bot.yourdomain.com ya amritmental.com"
                    className="flex-1 min-w-[240px] px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono text-cyan-300 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>

                {/* DNS Records Table */}
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-900/90 text-slate-400 text-[11px]">
                      <tr>
                        <th className="py-2 px-3">Record Type</th>
                        <th className="py-2 px-3">Name / Host</th>
                        <th className="py-2 px-3">Target / Value (Points to)</th>
                        <th className="py-2 px-3">TTL</th>
                        <th className="py-2 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      <tr>
                        <td className="py-2.5 px-3 font-bold text-cyan-400">CNAME</td>
                        <td className="py-2.5 px-3 text-white">
                          {userDomainInput ? (userDomainInput.includes('.') && userDomainInput.split('.').length > 2 ? userDomainInput.split('.')[0] : '@') : 'bot'}
                        </td>
                        <td className="py-2.5 px-3 text-emerald-400">
                          amrit-mental-bot-cloud.onrender.com
                        </td>
                        <td className="py-2.5 px-3 text-slate-500">Automatic / 3600</td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleCopy('amrit-mental-bot-cloud.onrender.com', 'cname_val')}
                            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] cursor-pointer"
                          >
                            {copiedCmd === 'cname_val' ? 'Copied!' : 'Copy Value'}
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-[11px] text-slate-400">
                  ⚡ DNS add karne ke 2 minute ke andar Render automatically <strong>Free SSL Certificate (https://)</strong> issue kar dega, aur aapka website poori duniya mein bina kisi 403 error ke live rahega!
                </p>
              </div>
            </div>

            {/* Live Ping & SLA Monitor Card */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Engine Uptime</span>
                <div className="text-xl font-mono font-bold text-emerald-400">
                  {serverHealth ? `${Math.floor(serverHealth.uptime / 3600)}h ${Math.floor((serverHealth.uptime % 3600) / 60)}m` : 'Online 24/7'}
                </div>
                <span className="text-[10px] text-slate-500">Auto-restores on crash</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Watchdog Shield</span>
                <div className="text-xl font-bold text-cyan-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>Self-Healing</span>
                </div>
                <span className="text-[10px] text-slate-500">Auto-restart counter resets on 60s stability</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Heartbeat Latency</span>
                <div className="text-xl font-mono font-bold text-purple-400">
                  {pingResult ? `${pingResult.latencyMs} ms` : 'Click Test Ping'}
                </div>
                <span className="text-[10px] text-slate-500">
                  {pingResult ? `Status: ${pingResult.status} (RAM: ${pingResult.memoryMB || 45}MB)` : 'Response verification'}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Persistent Storage</span>
                <div className="text-xl font-mono font-bold text-amber-400">database.json</div>
                <span className="text-[10px] text-slate-500">Saves all instances across server reboots</span>
              </div>
            </div>

            {/* External Keep-Alive Pinger Setup Guide */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-white">1. External Keep-Alive Pinger (Never Let Server Sleep)</h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Google Cloud Run aur Render idle hone par server ko sleep mode me daal dete hain. Isko <strong>hamesha ke liye 24/7 active rakhne ke liye</strong> kisi bhi free uptime monitor (jaise UptimeRobot ya Cron-Job.org) me yeh URL daalein:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                <div className="font-mono text-xs text-cyan-300 truncate">
                  {keepAliveUrl}
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(keepAliveUrl, 'keepalive_forever')}
                  className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedCmd === 'keepalive_forever' ? 'Copied!' : 'Copy Ping URL'}</span>
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-400">
                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                  <span className="font-bold text-slate-200">👉 UptimeRobot Setup (Free 24/7):</span>
                  <p>1. Open <a href="https://uptimerobot.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">UptimeRobot.com</a></p>
                  <p>2. Click <strong>Add New Monitor</strong></p>
                  <p>3. Monitor Type: <strong>HTTP(s)</strong>, Interval: <strong>5 minutes</strong></p>
                  <p>4. Paste your Ping URL above & Save!</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                  <span className="font-bold text-slate-200">👉 Cron-Job.org Setup (Free 24/7):</span>
                  <p>1. Open <a href="https://cron-job.org" target="_blank" rel="noreferrer" className="text-cyan-400 underline">Cron-job.org</a></p>
                  <p>2. Create a Cronjob with URL set to your Ping URL</p>
                  <p>3. Execution Schedule: <strong>Every 4 minutes</strong></p>
                  <p>4. Status: Active & Enabled forever!</p>
                </div>
              </div>
            </div>

            {/* Permanent Free Hosting Architectures */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <span>2. Permanent Free 24/7 Deployment Architectures (Salo Tak Chalne Wale Options)</span>
              </h3>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Architecture 1: Hugging Face Spaces */}
                <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span className="font-bold text-sm text-white">Hugging Face Spaces (Free 24/7 Forever)</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      100% Free, 16GB RAM, No Credit Card, <strong>kabhi sleep nahi hota!</strong>
                    </p>
                    <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
                      <li>HuggingFace.co par naya Space banayein (Docker SDK)</li>
                      <li>Ye script aur Dockerfile upload karein</li>
                      <li>Settings &gt; Variables me `BOT_TOKENS` aur `OWNER_ID` daalein</li>
                      <li>Years tak 24/7 non-stop run hoga!</li>
                    </ul>
                  </div>
                  <a
                    href="https://huggingface.co/spaces"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open Hugging Face Spaces</span>
                  </a>
                </div>

                {/* Architecture 2: VPS Linux Systemd Daemon */}
                <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-emerald-400" />
                      <span className="font-bold text-sm text-white">Linux VPS / Ubuntu Systemd Daemon</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Server restart hone par bhi bot automatically start hoga aur crash hone par 5s me wapis uth jayega!
                    </p>
                    <div className="p-2.5 rounded-lg bg-slate-950 font-mono text-[10px] text-slate-300 leading-normal overflow-x-auto">
                      [Unit]<br />
                      Description=Amrit Mental 24/7<br />
                      After=network.target<br />
                      [Service]<br />
                      ExecStart=/usr/bin/python3 /root/amrit_mental_upgraded.py<br />
                      Restart=always<br />
                      RestartSec=5s<br />
                      [Install]<br />
                      WantedBy=multi-user.target
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopy(
                        `[Unit]\nDescription=Amrit Mental 24/7 Fleet\nAfter=network.target\n\n[Service]\nType=simple\nUser=root\nWorkingDirectory=/root\nExecStart=/usr/bin/python3 /root/amrit_mental_upgraded.py\nRestart=always\nRestartSec=5s\n\n[Install]\nWantedBy=multi-user.target`,
                        'systemd_service'
                      )
                    }
                    className="w-full py-2.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{copiedCmd === 'systemd_service' ? 'Copied Service File!' : 'Copy amrit-bot.service'}</span>
                  </button>
                </div>

                {/* Architecture 3: Render / Koyeb Background Worker */}
                <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Cloud className="w-4 h-4 text-purple-400" />
                      <span className="font-bold text-sm text-white">Render / Koyeb Free Worker</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Background worker process jo port expose kiye bina 24/7 background me Telegram polling chalata hai.
                    </p>
                    <div className="p-2.5 rounded-lg bg-slate-950 font-mono text-[10px] text-slate-300 space-y-1">
                      <div><strong>Procfile:</strong> worker: python3 amrit_mental_upgraded.py</div>
                      <div><strong>Requirements:</strong> python-telegram-bot==21.6 httpx aiohttp</div>
                    </div>
                  </div>
                  <a
                    href="https://dashboard.render.com"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold flex items-center justify-center gap-2 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Deploy on Render Worker</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Public Access & Share Card */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-white flex items-center gap-2">
                  <Radio className="w-4 h-4 text-cyan-400" />
                  <span>Public Web Dashboard URL</span>
                </span>
                <p className="text-xs text-slate-400">
                  Yeh dashboard public internet par hosted hai — aap kisi bhi phone ya browser se access kar sakte hain.
                </p>
                <div className="font-mono text-xs text-cyan-300 truncate max-w-lg">
                  {typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-u7v6rsqr2bf7zrx7wn5jwm-244882406374.asia-southeast1.run.app'}
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(typeof window !== 'undefined' ? window.location.origin : '', 'dashboard_url')}
                className="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedCmd === 'dashboard_url' ? 'Copied Public URL!' : 'Copy Public Web Link'}</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <span>AMRIT X MENTAL • 24/7 Multi-User Bot Hosting Engine</span>
          <span className="font-mono text-slate-600">Built for AMRIT X MENTAL • All Rights Reserved</span>
        </div>
      </footer>

      {/* Public Share & Mobile App Installation Modal */}
      {publicShareModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/40 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 to-indigo-950/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">AMRIT X MENTAL • Public Web & Mobile App</h3>
                  <p className="text-xs text-slate-400">Sabhi ke liye open public link aur phone me install karne ka guide</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPublicShareModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto">
              {/* Public Link Box */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Official 100% Public URL (No Login Required)</span>
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Live Worldwide
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Yeh link <strong>bilkul public hai</strong> — kisi ko bhi bhejoge to seedha bina 403 error ke khulega:
                </p>
                <div className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-cyan-300 flex items-center justify-between gap-3 border border-slate-800">
                  <span className="truncate">https://ais-pre-u7v6rsqr2bf7zrx7wn5jwm-244882406374.asia-southeast1.run.app</span>
                  <button
                    type="button"
                    onClick={() => handleCopy('https://ais-pre-u7v6rsqr2bf7zrx7wn5jwm-244882406374.asia-southeast1.run.app', 'modal_public_url')}
                    className="px-3 py-1.5 rounded-md bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 transition-colors shrink-0 cursor-pointer"
                  >
                    {copiedCmd === 'modal_public_url' ? 'Copied!' : 'Copy Link'}
                  </button>
                </div>
              </div>

              {/* Install PWA on Phone */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm font-bold text-white">1. Phone Me Real App Ki Tarah Install Karein</span>
                  </div>
                  {isInstallable && (
                    <button
                      type="button"
                      onClick={() => {
                        installPWA();
                        setPublicShareModalOpen(false);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all cursor-pointer"
                    >
                      📲 Click to Install Now
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80 space-y-1">
                    <span className="font-bold text-emerald-400">🤖 Android (Chrome):</span>
                    <p>1. Chrome me yeh public link kholein</p>
                    <p>2. Upar 3 dots (⋮) par tap karein</p>
                    <p>3. <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> par click karein</p>
                    <p className="text-[11px] text-slate-500">Phone ke desktop par AMRIT X MENTAL icon aa jayega!</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80 space-y-1">
                    <span className="font-bold text-indigo-400">🍎 iPhone / iPad (Safari):</span>
                    <p>1. Safari me public link kholein</p>
                    <p>2. Niche <strong>Share Button</strong> (square with arrow) dabayein</p>
                    <p>3. Scroll karke <strong>"Add to Home Screen"</strong> par tap karein</p>
                    <p className="text-[11px] text-slate-500">Full screen bina browser bar ke open hoga!</p>
                  </div>
                </div>
              </div>

              {/* Convert to Standalone APK */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span className="text-sm font-bold text-white">2. Android APK File Banane Ka Tareeqa (Free)</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Agar aap is web app ko <strong>.apk file</strong> me convert karke doston ko send karna chahte hain:
                </p>
                <div className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-slate-300 space-y-1.5 border border-slate-800">
                  <p>1. <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">PWABuilder.com</a> kholein</p>
                  <p>2. Public URL paste karein: <span className="text-amber-300 select-all">https://ais-pre-u7v6rsqr2bf7zrx7wn5jwm-244882406374.asia-southeast1.run.app</span></p>
                  <p>3. <strong>Package for Android</strong> par click karein aur free me APK download kar lein!</p>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setPublicShareModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS Safari Guide Modal */}
      {showIOSInstallGuide && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 text-center">
            <Smartphone className="w-10 h-10 text-cyan-400 mx-auto" />
            <h3 className="text-base font-bold text-white">Install on iPhone / iOS</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Apple Safari browser me install karne ke liye:
              <br /><br />
              1. Safari browser me niche <strong>Share</strong> icon par tap karein.
              <br />
              2. Scroll karke <strong>"Add to Home Screen"</strong> par tap karein.
              <br />
              3. Upar <strong>Add</strong> dabayein.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSInstallGuide(false)}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
            >
              Samajh Gaya (Done)
            </button>
          </div>
        </div>
      )}

      {/* Easy Setup Guide Modal (आसान तरीका) */}
      {easySetupModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-amber-500/40 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 to-amber-950/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Zip File Setup Kaise Karein? (Super Easy Guide)</h3>
                  <p className="text-xs text-slate-400">Bina kisi confusion ke 2 sabse aasan tareeqe (Cloud 24/7 ya PC)</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEasySetupModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 overflow-y-auto">
              {/* Quick Zip Download Bar */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/50 to-blue-950/50 border border-cyan-500/30 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-cyan-300">Pehle Zip Download Kar Lein:</div>
                  <div className="text-[11px] text-slate-400">Is zip me start.bat, start.sh, Dockerfile aur poora system hai</div>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadFullProjectZip}
                  className="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download amrit_mental_fullstack.zip</span>
                </button>
              </div>

              {/* TARIQA 1: Render.com Free 24/7 Cloud (RECOMMENDED) */}
              <div className="p-5 rounded-xl bg-slate-900/90 border border-purple-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-purple-500 text-slate-950 font-black text-xs flex items-center justify-center">1</span>
                    <span className="font-bold text-white text-sm">🌟 Tareeqa 1: 24/7 Free Cloud Setup (Sabse Best & Recommended)</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    No PC Needed • 24/7 On
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Isme na laptop on rakhna padega na computer! Phone se bhi 24/7 saalo tak chalta rahega aur kabhi 403 error nahi aayega:
                </p>
                <div className="space-y-2 text-xs text-slate-300 font-sans">
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                    <div className="font-bold text-purple-300">Step A: GitHub Par Zip Upload Karein (1 Min)</div>
                    <p className="text-slate-400">1. <a href="https://github.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">GitHub.com</a> par account kholein.</p>
                    <p className="text-slate-400">2. <strong>New repository</strong> banayein (jaise: <code className="text-purple-300">amrit-bot-host</code>).</p>
                    <p className="text-slate-400">3. Download ki hui zip ko extract karein aur saari files ko GitHub par upload karke <strong>Commit changes</strong> kar dein.</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-300">Step B: Render.com Par 1-Click Deploy Karein (Free)</div>
                    <p className="text-slate-400">1. <a href="https://render.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">Render.com</a> kholein aur GitHub se login karein.</p>
                    <p className="text-slate-400">2. <strong>New +</strong> dabakar <strong>Web Service</strong> chunein.</p>
                    <p className="text-slate-400">3. Apna GitHub repo chunein — Render automatically hamara <code className="text-emerald-300">Dockerfile</code> pakad lega!</p>
                    <p className="text-slate-400">4. Plan: <strong>Free</strong> select karein aur <strong>Deploy Web Service</strong> dabayein.</p>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-200">
                    🎉 <strong>Kaam Khatam!</strong> 2 minute me aapko aapka permanent link mil jayega jo 24/7 chalega aur koi bhi banda is link par apna bot host kar sakega!
                  </div>
                </div>
              </div>

              {/* TARIQA 2: Windows PC Par (1-Click) */}
              <div className="p-5 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">2</span>
                    <span className="font-bold text-white text-sm">💻 Tareeqa 2: Apne Windows PC / Laptop Par Chalana</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                    1-Click Batch File
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 text-xs text-slate-300">
                  <p>1. Download ki hui <code className="text-cyan-300">amrit_mental_fullstack.zip</code> ko Right Click karke <strong>Extract All</strong> karein.</p>
                  <p>2. Folder ke andar <code className="text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/40">start.bat</code> file par <strong>Double Click</strong> karein!</p>
                  <p>3. Bas! Yeh automatically dependencies install karega aur aapke browser mein <code className="text-cyan-300 font-mono">http://localhost:3000</code> open kar dega!</p>
                  <p className="text-[11px] text-slate-500">
                    (Note: Agar PC me Node.js ya Python nahi hai to pehle nodejs.org aur python.org se download kar lein).
                  </p>
                </div>
              </div>

              {/* TARIQA 3: Linux / VPS / Mac */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                <span className="font-bold text-slate-200">🐧 Linux / VPS / Mac User Hain?</span>
                <p className="text-slate-400">Terminal me folder khol kar sirf yeh commands run karein:</p>
                <div className="p-2.5 rounded bg-slate-950 font-mono text-[11px] text-emerald-300 select-all border border-slate-800">
                  chmod +x start.sh && ./start.sh
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setEasySetupModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors cursor-pointer"
              >
                Samajh Gaya (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Script Code Viewer Modal */}
      {scriptModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
              <div className="flex items-center gap-2.5">
                <FileCode className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-white text-sm">amrit_mental_upgraded.py</h3>
                  <span className="text-[11px] text-slate-400">Complete Script • 4,140 Lines • Ready to Run</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyFullScript}
                  className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy All Code</span>
                </button>
                <a
                  href="/api/download-script"
                  download="amrit_mental_upgraded.py"
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .py</span>
                </a>
                <button
                  type="button"
                  onClick={() => setScriptModalOpen(false)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="p-4 flex-1 overflow-auto bg-slate-950 font-mono text-xs text-slate-300 leading-relaxed select-all">
              {loadingScript ? (
                <div className="flex items-center justify-center py-20 text-slate-500 gap-2">
                  <RotateCw className="w-5 h-5 animate-spin text-cyan-400" />
                  <span>Loading full script...</span>
                </div>
              ) : (
                <pre className="whitespace-pre">{rawScriptCode}</pre>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
