@echo off
title AMRIT X MENTAL 24/7 Bot Cloud Engine
echo =======================================================
echo   AMRIT X MENTAL 24/7 Telegram Bot Fleet Engine
echo =======================================================
echo.
echo [1/3] Checking Node.js and Python...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js nahi mila! Kripya https://nodejs.org se install karein.
    pause
    exit /b
)
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python nahi mila! Kripya https://python.org se install karein (Add to PATH tick karein).
    pause
    exit /b
)

echo [2/3] Installing Python and Node dependencies (sirf pehli baar time lagega)...
pip install python-telegram-bot==21.6 httpx aiohttp
call npm install

echo [3/3] Building and Starting Server on Port 3000...
echo.
echo Server khul raha hai: http://localhost:3000
start http://localhost:3000
npm start
pause
